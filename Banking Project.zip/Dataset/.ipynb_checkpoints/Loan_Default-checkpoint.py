import streamlit as st
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
import numpy as np

# Load the saved Logistic Regression model and scaler
logreg_model = joblib.load('Loan Models/logistic_regression_model.pkl')
scaler = joblib.load('Loan Models/scaler.pkl')

# Step 1: Define the function to predict repayment status
def predict_repayment_status(age, income, credit_score, loan_amount, interest_rate, loan_term):
    # Step 2: Create a DataFrame for the input features
    input_data = pd.DataFrame({
        'age': [age],
        'income': [income],
        'credit_score': [credit_score],
        'loan_amount': [loan_amount],
        'interest_rate': [interest_rate],
        'loan_term': [loan_term]
    })
    
    # Step 3: Derive additional features based on the input data
    input_data['monthly_income'] = input_data['income'] / 12
    input_data['monthly_payment'] = (input_data['loan_amount'] * (1 + (input_data['interest_rate'] / 100))) / input_data['loan_term']
    input_data['debt_to_income_ratio'] = input_data['monthly_payment'] / input_data['monthly_income']
    input_data['loan_to_income_ratio'] = input_data['loan_amount'] / input_data['income']
    
    # Step 4: Ensure input_data has the same column order as the model was trained with
    input_data = input_data[['age', 'income', 'credit_score', 'loan_amount', 'interest_rate', 
                             'loan_term', 'monthly_income', 'monthly_payment', 'debt_to_income_ratio', 
                             'loan_to_income_ratio']]

    # Step 5: Scale the input data (using the scaler fitted during training)
    input_scaled = scaler.transform(input_data)
    
    # Step 6: Predict repayment status
    prediction = logreg_model.predict(input_scaled)
    
    # Step 7: Return the prediction (Default or Not Default)
    return 'Default' if prediction[0] == 1 else 'Not Default'

# Streamlit UI for input
st.title('Loan Default Prediction')

age = st.number_input('Age', min_value=18, max_value=100, value=30)
income = st.number_input('Income', min_value=10000, max_value=1000000, value=50000)
credit_score = st.number_input('Credit Score', min_value=300, max_value=850, value=700)
loan_amount = st.number_input('Loan Amount', min_value=10000, max_value=1000000, value=200000)
interest_rate = st.number_input('Interest Rate (%)', min_value=0.1, max_value=30.0, value=5.0)
loan_term = st.number_input('Loan Term (Years)', min_value=1, max_value=30, value=15)

if st.button('Predict Repayment Status'):
    result = predict_repayment_status(age, income, credit_score, loan_amount, interest_rate, loan_term)
    st.write(f"Predicted repayment status: {result}")
