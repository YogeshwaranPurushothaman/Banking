# streamlit_app.py
import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load models and data
svd = joblib.load('Models/svd_model.pkl')
reconstructed_df = pd.read_pickle('Models/reconstructed_matrix.pkl')

st.title("📦 Product Recommendation Dashboard")

# Sidebar filters
st.sidebar.header("🔍 Filters")
customer_ids = reconstructed_df.index.tolist()
selected_customer = st.sidebar.selectbox("Select Customer ID", customer_ids)
top_k = st.sidebar.slider("Top K Recommendations", min_value=1, max_value=20, value=5)

# Recommend top-K products
customer_scores = reconstructed_df.loc[selected_customer].sort_values(ascending=False)
top_products = customer_scores.head(top_k)

st.subheader(f"🎯 Top {top_k} Recommendations for Customer: {selected_customer}")
st.table(top_products.reset_index().rename(columns={selected_customer: "Score", "index": "Product"}))


