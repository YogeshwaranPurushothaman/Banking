import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import seaborn as sns

# Load the KMeans model and scaler from the specified path
kmeans = joblib.load('Segmentation\kmeans_model.pkl')

# Function to process the input data and predict segments
def process_data(input_data):
    # Define the expected columns that the model was trained on (ensure these match exactly with what was used during training)
    expected_columns = ['recency', 'frequency', 'monetary', 'avg_transaction_amount', 'customer_lifetime','segment']  # Adjust columns based on your training data
    
    # Keep only numeric columns (excluding 'customer_id') and ensure the right columns are used
    numeric_data = input_data[expected_columns]
    
    # Predict clusters
    input_data['segment'] = kmeans.predict(numeric_data)
    
    # Map the segment labels
    segment_labels = {
        0: 'Casual Customer',
        1: 'Engaged Customer',
        2: 'VIP Customer',
        3: 'Dormant Customer'
    }
    input_data['segment_label'] = input_data['segment'].map(segment_labels)
    
    return input_data

# Streamlit App UI
st.title("Customer Segmentation with K-Means")

# Load pre-scaled data from CSV
scaled_data_file = 'Segmentation\Scaled_data.csv'

# Check if the file exists and load it
try:
    customer_data = pd.read_csv(scaled_data_file)
except FileNotFoundError:
    st.error(f"Error: The file {scaled_data_file} was not found.")
    customer_data = None

# Check if data is loaded successfully
if customer_data is not None:

    # Dropdown for selecting customer IDs
    customer_ids = customer_data['customer_id'].unique()  # Get unique customer IDs from the data
    selected_customer_id = st.selectbox("Select Customer ID", customer_ids)

    # Filter data for the selected customer ID
    selected_customer_data = customer_data[customer_data['customer_id'] == selected_customer_id]

    # Apply segmentation
    try:
        segmented_data = process_data(selected_customer_data)
        # Display results
        st.write("Customer Segmentation Results:")
        st.write(segmented_data[['customer_id', 'segment', 'segment_label']])
   
    except ValueError as e:
        st.error(str(e))
